// App.js
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// Importa todas tus pantallas
import WelcomeScreen from './screens/WelcomeScreen'; // Tu nueva landing page
import LoginScreen from './screens/LoginScreen';
import RegisterScreen from './screens/RegisterScreen';
import HomeScreen from './screens/HomeScreen'; // Tu pantalla principal después del login

// Importa tus otras pantallas principales
import AboutScreen from './screens/AboutScreen';
import ContactScreen from './screens/ContactScreen';
import RoutineDetailScreen from './screens/RoutineDetailScreen';
import RoutinesScreen from './screens/RoutinesScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Welcome">
        {/* Pantalla inicial (Landing Page) */}
        <Stack.Screen
          name="Welcome"
          component={WelcomeScreen}
          options={{ headerShown: false }} // Oculta el encabezado para la landing page
        />

        {/* --- Authentication Flow --- */}
        <Stack.Screen
          name="Login"
          component={LoginScreen}
          options={{ headerShown: false }} // Oculta el encabezado
        />
        <Stack.Screen
          name="Register"
          component={RegisterScreen}
          options={{ headerShown: false }} // Oculta el encabezado
        />

        {/* --- Main Application Flow --- */}
        {/* Estas pantallas solo deberían ser accesibles después de iniciar sesión */}
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{ title: 'Dashboard' }} // Título del encabezado para Home
        />
        <Stack.Screen name="About" component={AboutScreen} />
        <Stack.Screen name="Contact" component={ContactScreen} />
        <Stack.Screen name="RoutineDetail" component={RoutineDetailScreen} />
        <Stack.Screen name="Routines" component={RoutinesScreen} />
        {/* Agrega aquí cualquier otra pantalla principal de tu aplicación */}

      </Stack.Navigator>
    </NavigationContainer>
  );
}