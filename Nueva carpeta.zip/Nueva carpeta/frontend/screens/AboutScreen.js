import React from 'react';
import { View, Text } from 'react-native';
export default function AboutScreen() { return <View><Text>Sobre Nosotros</Text></View>; }