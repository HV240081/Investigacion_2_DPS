import React from 'react';
import { View, Text } from 'react-native';
export default function ContactScreen() { return <View><Text>Contáctanos</Text></View>; }