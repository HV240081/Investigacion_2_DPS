// screens/Auth/LoginScreen.js

import React, { useState } from 'react';
import {
    View,
    Text,
    TextInput,
    Button,
    StyleSheet,
    Alert, // Aunque no la usaremos para el login directo, la mantenemos por si la necesitas más tarde.
    TouchableOpacity
} from 'react-native';

const LoginScreen = ({ navigation }) => {
    // Mantenemos los estados por si en el futuro quieres volver a la lógica de credenciales
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleLogin = () => {
        // --- ¡IMPORTANTE! NAVEGACIÓN DIRECTA A HOMESCREEN PARA PRUEBAS ---
        // Al presionar el botón "Login", te llevará directamente a la pantalla 'Home'.
        // Esto ignora cualquier validación de email/contraseña.
        navigation.replace('Home'); // Usa 'replace' para que no puedas volver a la pantalla de login con el botón de retroceso.

        // Puedes comentar o eliminar las siguientes líneas si no las necesitas para el desarrollo
        console.log('Navegando directamente a Home para pruebas.');
        // Alert.alert('Modo de Prueba', 'Saltando el proceso de login y yendo directamente a Home.');
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Ingresar</Text>

            <TextInput
                style={styles.input}
                placeholder="Correo electrónico (ignorado en modo demo)"
                keyboardType="email-address"
                autoCapitalize="none"
                value={email}
                onChangeText={setEmail}
                // Si quieres, puedes deshabilitar el input cuando está en modo demo para que sea más claro
                // editable={false}
            />

            <TextInput
                style={styles.input}
                placeholder="Contraseña (ignorada en modo demo)"
                secureTextEntry
                value={password}
                onChangeText={setPassword}
                // editable={false}
            />

            {/* El botón "Login" ahora te lleva directamente a Home */}
            <Button title="Login (Acceso Directo a Home)" onPress={handleLogin} color="#0057D9" />

            <TouchableOpacity
                onPress={() => navigation.navigate('Register')}
                style={styles.registerLink}
            >
                <Text style={styles.registerText}>
                    ¿No tienes una cuenta? <Text style={styles.registerLinkText}>Regístrate aquí</Text>
                </Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
        backgroundColor: '#f8f8f8',
    },
    title: {
        fontSize: 32,
        fontWeight: 'bold',
        marginBottom: 30,
        color: '#333',
    },
    input: {
        width: '100%',
        height: 50,
        backgroundColor: '#fff',
        borderRadius: 8,
        paddingHorizontal: 15,
        marginBottom: 15,
        borderColor: '#ddd',
        borderWidth: 1,
        fontSize: 16,
    },
    registerLink: {
        marginTop: 20,
    },
    registerText: {
        fontSize: 16,
        color: '#666',
    },
    registerLinkText: {
        color: '#007bff',
        fontWeight: 'bold',
    },
});

export default LoginScreen;
