// screens/Auth/RegisterScreen.js

import React, { useState } from 'react';
import {
    View,
    Text,
    TextInput,
    Button,
    StyleSheet,
    Alert,
    TouchableOpacity
} from 'react-native';

const RegisterScreen = ({ navigation }) => {
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    const handleRegister = () => {
        // --- IMPORTANT: This is a placeholder for your actual backend registration. ---
        // In a real application, you would send 'username', 'email', and 'password' to your backend
        // (e.g., an API endpoint, Firebase, etc.) to create a new user.
        // Upon successful registration, you might automatically log them in or redirect to the login screen.

        if (username === '' || email === '' || password === '' || confirmPassword === '') {
            Alert.alert('Error', 'Please fill in all fields.');
            return;
        }

        if (password !== confirmPassword) {
            Alert.alert('Error', 'Passwords do not match.');
            return;
        }

        // Basic email format validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            Alert.alert('Error', 'Please enter a valid email address.');
            return;
        }

        // Simulate a successful registration
        // In a real app, you'd make an API call here.
        // If the registration is successful:
        Alert.alert('Registration Successful', 'You can now log in.');
        navigation.navigate('Login'); // Navigate back to the Login screen

        console.log('Attempting registration with:', { username, email, password });
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Register</Text>

            <TextInput
                style={styles.input}
                placeholder="Username"
                autoCapitalize="none"
                value={username}
                onChangeText={setUsername}
            />

            <TextInput
                style={styles.input}
                placeholder="Email"
                keyboardType="email-address"
                autoCapitalize="none"
                value={email}
                onChangeText={setEmail}
            />

            <TextInput
                style={styles.input}
                placeholder="Password"
                secureTextEntry
                value={password}
                onChangeText={setPassword}
            />

            <TextInput
                style={styles.input}
                placeholder="Confirm Password"
                secureTextEntry
                value={confirmPassword}
                onChangeText={setConfirmPassword}
            />

            <Button title="Register" onPress={handleRegister} />

            <TouchableOpacity
                onPress={() => navigation.navigate('Login')} // Navigate back to Login screen
                style={styles.loginLink}
            >
                <Text style={styles.loginText}>
                    Already have an account? <Text style={styles.loginLinkText}>Login here</Text>
                </Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
        backgroundColor: '#f8f8f8',
    },
    title: {
        fontSize: 32,
        fontWeight: 'bold',
        marginBottom: 30,
        color: '#333',
    },
    input: {
        width: '100%',
        height: 50,
        backgroundColor: '#fff',
        borderRadius: 8,
        paddingHorizontal: 15,
        marginBottom: 15,
        borderColor: '#ddd',
        borderWidth: 1,
    },
    loginLink: {
        marginTop: 20,
    },
    loginText: {
        fontSize: 16,
        color: '#666',
    },
    loginLinkText: {
        color: '#007bff',
        fontWeight: 'bold',
    },
});

export default RegisterScreen;