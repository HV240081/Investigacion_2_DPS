// screens/WelcomeScreen.js
import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Platform,
} from 'react-native';

const { width } = Dimensions.get('window');
const isTablet = width >= 768; // Punto de corte tablet
const isWeb = Platform.OS === 'web';

// Asegúrate de que esta pantalla reciba 'navigation' como prop
export default function WelcomeScreen({ navigation }) {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Image source={require('../assets/logo.png')} style={styles.logo} />
        {/* Aquí conectamos el botón "Ingresar" a la pantalla de Login */}
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('Login')} // Esto navegará a la pantalla de Login
        >
          <Text style={styles.buttonText}>Ingresar</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.splitBanner}>
        <View style={styles.bannerTextBox}>
          <Text style={styles.subtitle}>Entrena y aprende</Text>
          <Text style={styles.title}>CON COACH GYM</Text>
          <Text style={styles.title}>PARA SER TU MEJOR VERSIÓN</Text>
        </View>
        <Image
          source={require('../assets/banner.png')} // Asegúrate de que las rutas de las imágenes sean correctas
          style={styles.bannerImage}
        />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>PARA TODOS LOS NIVELES DE ENTRENAMIENTO</Text>
        <Text style={styles.description}>
          Si quieres mejorar tu calidad de vida y crear hábitos saludables en cuanto al entrenamiento,
          la nutrición, aquí encontrarás las herramientas necesarias (tanto teóricas como prácticas) para llevarlo a cabo.
        </Text>

        <View
          style={
            isWeb
              ? styles.imagesRowWeb
              : styles.imagesGridMobileTablet
          }
        >
          <Image source={require('../assets/img1.png')} style={styles.image} />
          <Image source={require('../assets/img2.png')} style={styles.image} />
          <Image source={require('../assets/img3.png')} style={styles.image} />
          <Image source={require('../assets/img4.png')} style={styles.image} />
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 15,
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  logo: {
    width: 80,
    height: 80,
    resizeMode: 'contain',
  },
  button: {
    backgroundColor: '#0057D9',
    paddingVertical: 8,
    paddingHorizontal: 18,
    borderRadius: 5,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  splitBanner: {
    flexDirection: 'row',
    backgroundColor: '#36374D',
    width: '100%',
    height: 220,
  },
  bannerTextBox: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  bannerImage: {
    width: width / 2,
    height: '100%',
    resizeMode: 'cover',
  },
  subtitle: {
    color: '#ccc',
    fontSize: 14,
    marginBottom: 8,
  },
  title: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },
  section: {
    padding: 20,
    alignItems: 'center',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  description: {
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 20,
    color: '#444',
  },
  imagesGridMobileTablet: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    paddingHorizontal: 10,
  },
  imagesRowWeb: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    flexWrap: 'nowrap',
  },
  image: {
    width: isWeb ? 200 : width / 2 - 100,
    height: isWeb ? 200 : width / 2 - 100,
    margin: 10,
    borderRadius: 12,
    resizeMode: 'cover',
  },
});